Para gerar os arquivos, use:

python generate.py 1000
