package priority_queue;

public interface Entry<K, V> {
	K getKey();
	V getValue();
}
