package search.sequential;

public interface Entry<K, V> {
	K getKey();
	V getValue();
}