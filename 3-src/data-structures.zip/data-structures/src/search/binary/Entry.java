package search.binary;

public interface Entry<K, V> {
	K getKey();
	V getValue();
}